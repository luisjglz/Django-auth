from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages


def index(request):
    if request.method == "POST":
        uname = request.POST['user']
        pwd = request.POST['password']
        user = authenticate(request, username=uname, password=pwd)
        if user is not None:
            #successful login, redirect to safe env
            login(request, user)
            return redirect('securepage')
        else:
            #bad login, redirect to login with error msg
            messages.success(request, ('Bad login'))
            return render(request, 'index.html', {})
    else:
        return render(request, 'index.html', {})

def securepage(request):
    return render(request, 'secure.html', {})



    




